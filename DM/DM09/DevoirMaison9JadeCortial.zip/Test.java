
public class Test {
	public static void main(String []args) {
		Arbre a = new Arbre(null);
		a.NPI("26*51-+");
		a.getRacine().parentheses();
		System.out.println();
	}
}
