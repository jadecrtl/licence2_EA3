public class Element {
	private int valeur;
	
	public Element(int val) {
		this.valeur = val;
	}
	
	public int getValeur() {
		return valeur;
	}
	
}
